//
//  lifttApp.swift
//  Shared
//
//  Created by Roscoe Kerby on 2021/12/13.
//

import SwiftUI

@main
struct lifttApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
