import 'package:flutter/material.dart';
import 'package:scoped_model/scoped_model.dart';
import 'dart:developer' as developer;

import './counter.dart';
import '../scoped_models/workouts.dart';

class AddWorkoutSet extends StatefulWidget {
  final int workoutIndex;
  final int exerciseIndex;

  const AddWorkoutSet(
    this.workoutIndex,
    this.exerciseIndex, {
    Key key,
  }) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return _AddWorkoutSetState();
  }
}

class _AddWorkoutSetState extends State<AddWorkoutSet> {
  int reps;
  int weight;
  int volume;

  @override
  void initState() {
    super.initState();
    reps = 5;
    weight = 50;
    volume = 0;
  }

  @override
  Widget build(BuildContext context) {
    return ScopedModelDescendant<WorkoutsModel>(builder: (
      BuildContext context,
      Widget child,
      WorkoutsModel model,
    ) {
      return InkWell(
        key: const Key('addWorkoutSetBtn'),
        child: Row(
          children: <Widget>[
            Icon(
              Icons.add_circle,
              color: Theme.of(context).colorScheme.secondary,
              size: 30.0,
            ),
            // ElevatedButton(
            //   onPressed: () {},
            //   // onPressed: () {
            //   //   volume = volume + weight * reps;
            //   // },
            //   child: Text(volume.toString()),
            // ),
          ],
        ),
        borderRadius: BorderRadius.circular(50.0),
        onTap: () {
          // developer.log(volume.toString());
          showModal(context).then((update) {
            if (update != null && update) {
              model.addWorkoutSet(
                widget.workoutIndex,
                widget.exerciseIndex,
                reps: reps,
                weight: weight,
                volume: volume,

                // volume: volume,
              );
              developer.log(volume.toString());
            }
          });
        },
      );
    });
  }

  Future<dynamic> showModal(
    BuildContext context,
  ) {
    return showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Column(
          children: <Widget>[
            const SizedBox(height: 15.0),
            Counter(
              startingValue: 5,
              onChanged: (value) {
                setState(() {
                  reps = value;
                  // volume = volume + weight * reps;
                });
              },
            ),
            const SizedBox(height: 20.0),
            Counter(
              startingValue: 50,
              increment: 5,
              onChanged: (value) {
                setState(() {
                  weight = value;
                  // volume = volume + weight * reps;
                });
              },
            ),
            const SizedBox(height: 20.0),
            ElevatedButton(
              key: const Key('addSetButton'),
              // onPressed: () => Navigator.pop(context, true),
              onPressed: () {
                setState(() {
                  volume = volume + weight * reps;
                  // volume = volume + weight * reps;
                });

                // volume = volume + weight * reps;
                Navigator.pop(context, true);
              },
              child: const Text('Add Set'),
              style: ElevatedButton.styleFrom(
                primary: Theme.of(context).colorScheme.secondary, // background
                onPrimary: Colors.white, // foreground
                // volume = volume + weight * reps;
              ),
            ),
          ],
        );
      },
    );
  }
}
