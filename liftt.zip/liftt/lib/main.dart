import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

import './app.dart';
import './scoped_models/workouts.dart';
import './scoped_models/exercises.dart';
import './services/workout_service_flutter.dart';
import './services/exercise_service_flutter.dart';

void main() async {
  WidgetsFlutterBinding
      .ensureInitialized(); // Ensures the binding is initialized

  // Retrieve the directory asynchronously since it's required for service initialization
  var getDir = await getApplicationDocumentsDirectory();

  var workoutService =
      WorkoutServiceFlutter(getDir as Future<Directory> Function());
  var exercisesService =
      ExerciseServiceFlutter(getDir as Future<Directory> Function());

  // Initializing the models with services
  WorkoutsModel workoutsModel = WorkoutsModel(
    workoutService: workoutService,
  );

  ExercisesModel exercisesModel = ExercisesModel(
    exerciseService: exercisesService,
  );

  // Running the app with the initialized models
  runApp(App(
    workoutsModel: workoutsModel,
    exercisesModel: exercisesModel,
    key: UniqueKey(),
  ));
}
